function execute() {
    return Response.success([
        {title: "华文作品", input:  "https://www.kanunu8.com/files/chinese/29-", script: "gen.js"},
        {title: "外国文学", input:  "https://www.kanunu8.com/files/world/8-", script: "gen.js"},
        {title: "青春校园", input:  "https://www.kanunu8.com/files/youth/21-", script: "gen.js"},
        {title: "古典文学", input:  "https://www.kanunu8.com/files/dushi/2-", script: "gen.js"},
        {title: "短篇作品", input:  "https://www.kanunu8.com/files/little/6-", script: "gen.js"},
        {title: "传记纪实", input:  "https://www.kanunu8.com/files/4.html", script: "gen1.js"},
        {title: "古典文学", input:  "https://www.kanunu8.com/files/2.html", script: "gen1.js"},
        {title: "经典游戏小说合集", input:  "https://www.kanunu8.com/files/3.html", script: "gen1.js"},
        {title: "盗墓小说大全", input:  "https://www.kanunu8.com/files/5.html", script: "gen1.js"},
        {title: "鬼故事大全", input:  "https://www.kanunu8.com/files/8.html", script: "gen1.js"}

    ]);
}