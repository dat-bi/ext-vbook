function execute() {
    return Response.success([
        {title: "Truyện mới cập nhật", input: "https://kyhuyen.com/tim-kiem?page=1", script: "gen.js"}
    ])
}
