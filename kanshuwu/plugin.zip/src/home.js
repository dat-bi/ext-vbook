function execute() {
    return Response.success([
        {title: "玄幻", input: "http://www.kanshuwu.org/fenlei/1/", script: "zen.js"},
        {title: "奇幻", input: "http://www.kanshuwu.org/fenlei/2/", script: "zen.js"},
        {title: "武侠", input: "http://www.kanshuwu.org/fenlei/3/", script: "zen.js"},
        {title: "仙侠", input: "http://www.kanshuwu.org/fenlei/4/", script: "zen.js"},
        {title: "都市", input: "http://www.kanshuwu.org/fenlei/5/", script: "zen.js"},
        {title: "军事", input: "http://www.kanshuwu.org/fenlei/6/", script: "zen.js"},
        {title: "历史", input: "http://www.kanshuwu.org/fenlei/7/", script: "zen.js"},
        {title: "游戏", input: "http://www.kanshuwu.org/fenlei/8/", script: "zen.js"},
        {title: "竞技", input: "http://www.kanshuwu.org/fenlei/9/", script: "zen.js"},
        {title: "科幻", input: "http://www.kanshuwu.org/fenlei/10/", script: "zen.js"},
        {title: "悬疑", input: "http://www.kanshuwu.org/fenlei/11/", script: "zen.js"}
    ]);
}