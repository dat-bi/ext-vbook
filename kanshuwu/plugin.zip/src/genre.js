function execute() {
    return Response.success([
        {title: "玄幻", input: "https://www.duanqingsi.com/fenlei/1/", script: "zen.js"},
        {title: "奇幻", input: "https://www.duanqingsi.com/fenlei/2/", script: "zen.js"},
        {title: "武侠", input: "https://www.duanqingsi.com/fenlei/3/", script: "zen.js"},
        {title: "仙侠", input: "https://www.duanqingsi.com/fenlei/4/", script: "zen.js"},
        {title: "都市", input: "https://www.duanqingsi.com/fenlei/5/", script: "zen.js"},
        {title: "军事", input: "https://www.duanqingsi.com/fenlei/6/", script: "zen.js"},
        {title: "历史", input: "https://www.duanqingsi.com/fenlei/7/", script: "zen.js"},
        {title: "游戏", input: "https://www.duanqingsi.com/fenlei/8/", script: "zen.js"},
        {title: "竞技", input: "https://www.duanqingsi.com/fenlei/9/", script: "zen.js"},
        {title: "科幻", input: "https://www.duanqingsi.com/fenlei/10/", script: "zen.js"},
        {title: "悬疑", input: "https://www.duanqingsi.com/fenlei/11/", script: "zen.js"}
    ]);
}