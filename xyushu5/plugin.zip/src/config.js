let BASE_URL = 'https://m.xyushu5.xyz';
try {
    if (CONFIG_URL) {
        BASE_URL = CONFIG_URL;
    }
} catch (error) {
}