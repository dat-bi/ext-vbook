let BASE_URL = 'https://dualeotruyenyk.com'
try {
    if (CONFIG_URL) {
        BASE_URL = CONFIG_URL;
    }
} catch (error) {
}