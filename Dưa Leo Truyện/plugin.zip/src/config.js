let BASE_URL = 'https://dualeotruyenat.com/'
try {
    if (CONFIG_URL) {
        BASE_URL = CONFIG_URL;
    }
} catch (error) {
}