load('config.js');
function execute(input) {
    let doc = Html.parse(input);
var comments = [];
// Lấy cả comment cha + reply
var items = doc.select("ul.comments li");

for (var i = 0; i < items.size(); i++) {
    var e = items.get(i);

    // Tên user
    var name = "";
    var nameEl = e.select(".post-comments p a span").first();
    if (nameEl != null) {
        name = nameEl.text().trim();
    }

    // Nội dung comment
    var content = "";
    var contentEl = e.select(".post-comments span.d-block.my-2").first();
    if (contentEl != null) {
        content = contentEl.text().trim();
    }

    // Bỏ những dòng rỗng (phòng trường hợp li không phải comment)
    if (name != "" || content != "") {
        comments.push({
            name: name,
            content: content
        });
    }
}

return Response.success(comments);
}