function execute() {
    return Response.success([
        {title: "玄幻", input: "/dudu-31/", script: "zen.js"},
        {title: "武侠", input: "/dudu-32/", script: "zen.js"},
        {title: "都市", input: "/dudu-33/", script: "zen.js"},
        {title: "历史", input: "/dudu-34/", script: "zen.js"},
        {title: "科幻", input: "/dudu-35/", script: "zen.js"},
        {title: "游戏", input: "/dudu-36/", script: "zen.js"},
        {title: "女生", input: "/dudu-37/", script: "zen.js"},
        {title: "其他", input: "/dudu-38/", script: "zen.js"},
        {title: "其他", input: "/dudu-40/", script: "zen.js"}
    ]);
}

/* <a href="/dudu-31/" title="都市重生" target="_top">都市重生</a> 
<a href="/dudu-32/" title="玄幻奇幻" target="_top">玄幻奇幻</a> 
<a href="/dudu-33/" title="仙侠修真" target="_top">仙侠修真</a> 
<a href="/dudu-34/" title="科幻小说" target="_top">科幻小说</a> 
<a href="/dudu-35/" title="二次元" target="_top">二次元</a> 
<a href="/dudu-36/" title="游戏竞技" target="_top">游戏竞技</a> 
<a href="/dudu-37/" title="女生言情" target="_top">女生言情</a> 
<a href="/dudu-38/" title="历史军事" target="_top">历史军事</a> 
<a href="/dudu-40/" title="灵异小说" target="_top">灵异小说</a> */