let BASE_URL = 'https://trumtruyen.live';
try {
    if (CONFIG_URL) {
        BASE_URL = CONFIG_URL;
    }
} catch (error) {
}