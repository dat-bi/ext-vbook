function execute() {
    return Response.success([
        {title: "玄幻", input: 'http://www.60ks.net/bookstore/xuanhuan/default-0-0-0-0-0-0-', script: "gen.js"},
        {title: "仙侠", input: 'http://www.60ks.net/bookstore/xianxia/default-0-0-0-0-0-0-', script: "gen.js"},
        {title: "都市", input: 'http://www.60ks.net/bookstore/dushi/default-0-0-0-0-0-0-', script: "gen.js"},
        {title: "军史", input: 'http://www.60ks.net/bookstore/lishi/default-0-0-0-0-0-0-', script: "gen.js"},
        {title: "悬疑", input: 'http://www.60ks.net/bookstore/xuanyi/default-0-0-0-0-0-0-', script: "gen.js"},
        {title: "网游", input: 'http://www.60ks.net/bookstore/wangyou/default-0-0-0-0-0-0-', script: "gen.js"},
        {title: "科幻", input: 'http://www.60ks.net/bookstore/kehuan/default-0-0-0-0-0-0-', script: "gen.js"},
        {title: "灵异", input: 'http://www.60ks.net/bookstore/chuanyue/default-0-0-0-0-0-0-', script: "gen.js"},
        {title: "穿越", input: 'http://www.60ks.net/bookstore/tongren/default-0-0-0-0-0-0-', script: "gen.js"},
        {title: "同人", input: 'http://www.60ks.net/bookstore/jingsong/default-0-0-0-0-0-0-', script: "gen.js"}
    ]);
}