function execute() {
    return Response.success([
        {title: "排行1", input: 'http://www.60ks.net/bookstore/xuanhuan/', script: "gen.js"},
        {title: "言情小说", input: 'http://www.60ks.net/bookstore/xianxia/', script: "gen.js"},
        {title: "仙侠修真", input: 'http://www.60ks.net/bookstore/dushi/', script: "gen.js"},
        {title: "都市小说", input: 'http://www.60ks.net/bookstore/lishi/', script: "gen.js"},
        {title: "历史小说", input: 'http://www.60ks.net/bookstore/xuanyi/', script: "gen.js"},
        {title: "网游小说", input: 'http://www.60ks.net/bookstore/wangyou/', script: "gen.js"},
        {title: "竞技小说", input: 'http://www.60ks.net/bookstore/kehuan/', script: "gen.js"},
        {title: "科幻小说", input: 'http://www.60ks.net/bookstore/chuanyue/', script: "gen.js"},
        {title: "科幻小说", input: 'http://www.60ks.net/bookstore/tongren/', script: "gen.js"},
        {title: "科幻小说", input: 'http://www.60ks.net/bookstore/jingsong/', script: "gen.js"}
    ]);
}