load('libs.js');
function execute(url)
function getKey(key) {
    const parts = key.split(";");
    for (let part of parts) {
        if (part.includes("secretKey2")) {
            return part.split("=")[1];
        }
    }
    return "";
}

eval(function (p, a, c, k, e, r) { e = function (c) { return (c < 62 ? '' : e(parseInt(c / 62))) + ((c = c % 62) > 35 ? String.fromCharCode(c + 29) : c.toString(36)) }; if ('0'.replace(0, e) == 0) { while (c--) r[e(c)] = k[c]; k = [function (e) { return r[e] || e }]; e = function () { return '[3-9abe-hl-oq-zA]' }; c = 1 }; while (c--) if (k[c]) p = p.replace(new RegExp('\\b' + e(c) + '\\b', 'g'), k[c]); return p }('function decrypt(4){3 i=4.5-1;while(i>=0){3 c=4.l(i);m(c!==\'\\n\'&&c!==\'\\u200c\'&&c!==\'\\o\')break;i--}3 8=4.q(0,i+1);3 r=4.q(i+1);3 9=[];3 a=r.split(\'\\o\');6(3 p=0;p<a.5;p++){3 b=a[p];m(b.5!==s)continue;3 e=\'\';6(3 j=0;j<s;j++){3 t=b.l(j);e+=t===\'\\n\'?\'0\':\'1\'}9.u(v.w(parseInt(e,2)))}3 f=9.x(\'\');3 7=0;6(3 k=0;k<f.5;k++){7+=f.y(k)}7%=g;3 h=[];6(3 d=0;d<8.5;d++){3 z=8.y(d);3 A=(z-7+g)%g;h.u(v.w(A))}return h.x(\'\')}', [], 37, '|||var|encryptedStr|length|for|shift|encryptedText|keyChars|parts|part|||binary|key|65536|decrypted||||charAt|if|u200b|u200d||substring|zwPart|16|bit|push|String|fromCharCode|join|charCodeAt|code|decryptedCode'.split('|'), 0, {}))
return null
    // let response = fetch(url);
    // let doc = response.html();
    // console.log(doc.select("body > script:nth-child(3)"))
    // url = "http://14.225.254.182/truyen/qidian/1/1040216164/" 
    // console.log(url)
    // var browser = Engine.newBrowser() // Khởi tạo browser
    // let doc = browser.launch(url, 5000) // Mở trang web với timeout, trả về Document object
    // browser.close() // Đóng browser khi đã xử lý xong
    // let text = doc.html()
    // console.log(text)
    //     var author = doc.select("i.cap").attr("onclick").replace(/location=\'\/\?find\=&findinname\=(.*?)\'/g, "$1");
    //     let des = doc.select(".blk:has(.fa-water) .blk-body").html();
    //     let _detail = doc.select("#inner > div.container.px-md-4.px-sm-0.px-0 > div:nth-child(5) .blk-body");
    //     _detail.select("a").remove();
    //     let suggests = [
    //         {
    //             title: "Truyện từ các nguồn khác:",
    //             input: doc.select("#book_name2").first().text(),
    //             script: "suggests.js"
    //         }
    //     ];
    //     let data = {
    //         name: doc.select("#oriname").text(),
    //         cover: doc.select('meta[property="og:image"]').first().attr("content"),
    //         author: author || 'Unknow',
    //         description: des,
    //         detail: _detail.html().replace(/\n/g, "<br>"),
    //         ongoing: true,
    //         host: "STVHOST",
    //         suggests: suggests,
    //     }
    //     return Response.success(data);
}


