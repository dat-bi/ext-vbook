load('libs.js');
load('config.js')
function execute(url) {
    console.log(get_csrfToken())
    // var _csrfToken = cookies.match(/_csrfToken=(.*?);/)[1];
    // log(_csrfToken)
    // let t = "https://m.qidian.com/majax/rank/reclist?gender=male&pageNum=2&_csrfToken=VGcimHqXEuhHG54BcVuOK2ho1WukStoalTmFIRZ6"
    // log(t.match(/_csrfToken(.*?)$/)[0])
    return null;
}
// https://www.qidian.com/rank/yuepiao/?source=m_jump/
// https://m.qidian.com/rank/yuepiao/