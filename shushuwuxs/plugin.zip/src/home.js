function execute() {
    return Response.success([
        { title: "玄幻", input: "/xuanhuan/", script: "gen.js" },
        { title: "武侠", input: "/wuxia/", script: "gen.js" },
        { title: "都市", input: "/dushi/", script: "gen.js" },
        { title: "历史", input: "/lishi/", script: "gen.js" },
        { title: "游戏", input: "/youxi/", script: "gen.js" },
        { title: "科幻", input: "/kehuan/", script: "gen.js" },
        { title: "恐怖", input: "/xuanyi/", script: "gen.js" },
        { title: "其他", input: "/qita/", script: "gen.js" },
        { title: "古代", input: "/guyan/", script: "gen.js" },
        { title: "现代", input: "/xianyan/", script: "gen.js" },
        { title: "幻想", input: "/huanqing/", script: "gen.js" },
        { title: "游戏", input: "/zongcai/", script: "gen.js" },
        { title: "浪漫", input: "/qingchun/", script: "gen.js" },
        { title: "言情", input: "/wangluo/", script: "gen.js" },
        { title: "科幻", input: "/mmkehuan/", script: "gen.js" },
        { title: "其他", input: "/mmqita/", script: "gen.js" },
    ]);
}
