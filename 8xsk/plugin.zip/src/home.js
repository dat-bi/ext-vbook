function execute() {
    return Response.success([
        {title: "玄幻奇幻", input:  "https://www.8xsk.com/xuanhuan", script: "gen.js"},
        {title: "仙侠修真", input:  "https://www.8xsk.com/xianxia", script: "gen.js"},
        {title: "穿越历史", input:  "https://www.8xsk.com/lishi", script: "gen.js"},
        {title: "都市言情", input:  "https://www.8xsk.com/dushi", script: "gen.js"},
        {title: "科幻网游", input:  "https://www.8xsk.com/kehuan", script: "gen.js"},
        {title: "女生视觉", input:  "https://www.8xsk.com/nvsheng", script: "gen.js"},
        {title: "精品辣文", input:  "https://www.8xsk.com/lawen", script: "gen.js"},
        {title: "精品其他", input:  "https://www.8xsk.com/jingpin", script: "gen.js"}
    ]);
}