load('config.js');
function execute(url) {
    url.replace(/^(?:https?:\/\/)?(?:[^@\n]+@)?(?:www\.)?([^:\/\n?]+)/img, BASE_URL)
    let doc = fetch(url).text();
    let token_ = doc.match(/_token = '(.*?)';/g)[0].replace("_token = '", "").replace("';", "");
    let cookies = doc.match(/cookies:\s*'([^']+)'/)[0].replace("cookies: '", "").replace("'", "");
    console.log( cookies);
    console.log(token_);
    // var response = fetch("https://daomeoden.net/apps/controllers/book/bookChapterContent.php", {
    //     method: "POST",
    //     body: {
    //         "index": "0",
    //         "page": page,
    //         "token": token_
    //     },
    // });

    // let json = response.json();
    // let datajson = Html.parse(json.data);
    // var el = doc.select("div.row img.w-100");
    // console.log(doc);
    // var data = [];
    // for (var i = 0; i < el.size(); i++) {
    //     var e = el.get(i);
    //     data.push("https:" + e.attr("data-src"));
    // }
    // return Response.success(data);
}
