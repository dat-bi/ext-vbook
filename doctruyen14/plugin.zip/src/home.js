function execute() {
    return Response.success([
        { title: "Truyện Sex", input: "https://doctruyen14.vip/truyen-sex-nguoi-lon/", script: "gen.js" },
        { title: "Truyện Ma", input: "https://doctruyen14.vip/truyen-ma/", script: "gen.js" },
        { title: "Truyện Teen", input: "https://doctruyen14.vip/truyen-teen/", script: "gen.js" },
        { title: "Truyện Tình Cảm", input: "https://doctruyen14.vip/truyen-tinh-cam/", script: "gen.js" },
        { title: "Truyện Cười", input: "https://doctruyen14.vip/truyen-cuoi/", script: "gen.js" },
        { title: "Truyện Gay", input: "https://doctruyen14.vip/truyen-gay/", script: "gen.js" },
        { title: "Truyện Les", input: "https://doctruyen14.vip/truyen-les/", script: "gen.js" }
    ]);
}
