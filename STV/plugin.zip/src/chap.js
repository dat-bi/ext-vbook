// function execute(url) {
//     if(url.slice(-1) !== "/")
//         url = url + "/";


//     return Response.success(el1);
//     function execute(url) {
//     let response = fetch(url);
//     if (response.ok)
//         return Response.success(response.html().select("#content-container.container").html());
//     return null;

// }


