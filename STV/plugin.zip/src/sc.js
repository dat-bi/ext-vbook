load('lib.js')
function execute(url) {



        // let data1 = Buffer.from('MS0lMkYtMS0lMkYtQ2glQzYlQjAlQzYl'+chapList, 'base64').toString();
        // console.log(data1); MS0lMkYtMTA5Mjg0NTkyLSUyRi0lMjBD
        // var data1 = atob('MS0lMkYtMS0lMkYtQ2glQzYlQjAlQzYl' + chapList)
        let chapList = decodeURIComponent(data2)
        console.log(chapList)

        let list1 = ['biqugeinfo', 'biqugexs', 'uuxs', 'zwdu'];
        let list12 = ['69shuorg', 'xbiquge',];
        let start;

    

}