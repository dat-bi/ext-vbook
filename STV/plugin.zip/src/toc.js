function execute(url) {
    if(url.slice(-1) !== "/")
        url = url + "/";
    let el1 =""
    var browser = Engine.newBrowser() // Khởi tạo browser
    let doc = browser.launch(url, 7000) // Mở trang web với timeout, trả về Document object
    el1 = doc.select("#chaptercontainerinner")
    browser.close()
    el1 = el1.html().replace(/<div class=\"row\">/g,"").replace(/\n/g,"").replace(/<div class=\"col-md-4\">/g,"").replace(/<\/div>/g,"").replace(/<\/a>    <a/g,"<\/a>\n<a").replace(/   /g,"").replace(/<\/a> /g,"<\/a>")
    doc= Html.parse(el1)
    var el = doc.select("a");
    var list = [];
    console.log(el)
    el.forEach(e => list.push({
            name: e.text(),
            url: "http://sangtacviet.pro" + e.attr("href"),
            host: "http://sangtacviet.pro"
        }));
    return Response.success(list);

}


