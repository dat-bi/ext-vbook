let BASE_URL = 'https://www.xinyushuwu2.org';
try {
    if (CONFIG_URL) {
        BASE_URL = CONFIG_URL;
    }
} catch (error) {
}