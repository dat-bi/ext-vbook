function execute() {
    return Response.success([
        {title: "耽美", input: "/sort/1/", script: "zen.js"},
        {title: "百合", input: "/sort/2/", script: "zen.js"},
        {title: "玄幻", input: "/sort/3/", script: "zen.js"},
        {title: "修真", input: "/sort/4/", script: "zen.js"},
        {title: "言情", input: "/sort/5/", script: "zen.js"},
        {title: "高辣", input: "/sort/6/", script: "zen.js"},
        {title: "腹黑", input: "/sort/7/", script: "zen.js"},
        {title: "种田", input: "/sort/8/", script: "zen.js"},
        {title: "高干", input: "/sort/9/", script: "zen.js"}
    ]);
}
