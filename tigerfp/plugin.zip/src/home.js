function execute() {
    return Response.success([
        { title: "玄幻", input: "https://www.tigerfp.com/leibie1/", script: "gen.js" },
        { title: "修真", input: "https://www.tigerfp.com/leibie2/", script: "gen.js" },
        { title: "都市", input: "https://www.tigerfp.com/leibie3/", script: "gen.js" },
        { title: "历史", input: "https://www.tigerfp.com/leibie4/", script: "gen.js" },
        { title: "网游", input: "https://www.tigerfp.com/leibie5/", script: "gen.js" },
        { title: "科幻", input: "https://www.tigerfp.com/leibie6/", script: "gen.js" },
        { title: "女生", input: "https://www.tigerfp.com/leibie7/", script: "gen.js" },
        { title: "二次元", input: "https://www.tigerfp.com/leibie8/", script: "gen.js" },
        { title: "其他", input: "https://www.tigerfp.com/leibie9/", script: "gen.js" }
    ]);
}
