function execute() {
    return Response.success([
        { title: "玄幻", input: "1", script: "gen.js" },
        { title: "修真", input: "1", script: "gen.js" },
        { title: "都市", input: "1", script: "gen.js" },
        { title: "穿越", input: "1", script: "gen.js" },
        { title: "网游", input: "1", script: "gen.js" },
    ]);
}
