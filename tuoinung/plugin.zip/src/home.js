function execute() {
    return Response.success([
        {title: "Truyện 18+", input: "https://tuoinung.com/truyen-18", script: "gen.js"},
        {title: "Dâm", input: "https://tuoinung.com/truyen-dam", script: "gen.js"},
        {title: "Sex", input: "https://tuoinung.com/truyen-sex", script: "gen.js"},
    ]);
}