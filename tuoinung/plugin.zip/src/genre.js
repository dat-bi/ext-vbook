function execute() {
        return Response.success([
        {title: "TOP", input: "https://tuoinung.com/tag/truyen-sex-hay", script: "tag.js"},
        {title: "Teen", input: "https://tuoinung.com/tag/truyen-teen", script: "tag.js"},
        {title: "ngoai-tinh", input: "https://tuoinung.com/tag/truyen-sex-ngoai-tinh", script: "tag.js"},
        {title: "pha-trinh", input: "https://tuoinung.com/tag/truyen-sex-pha-trinh", script: "tag.js"},
        {title: "hiep-dam", input: "https://tuoinung.com/tag/truyen-sex-hiep-dam", script: "tag.js"},
        {title: "co-giao", input: "https://tuoinung.com/tag/truyen-sex-co-giao#gsc.tab=0", script: "tag.js"},
        {title: "hoc-sinh", input: "https://tuoinung.com/tag/truyen-sex-hoc-sinh#gsc.tab=0", script: "tag.js"},
        {title: "hay", input: "https://tuoinung.com/tag/truyen-sex-hay", script: "tag.js"}
    ]);
}