function execute() {
        return Response.success([
        {title: "lên trang nguồn mà tìm truyện, rồi get truyện về ", input: "https://tuoinung.com/truyen-18", script: "gen.js"},
    ]);
}