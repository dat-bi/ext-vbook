function execute(url) {
    var browser = Engine.newBrowser();
    browser.setUserAgent(UserAgent.android());
    var doc = browser.launch(url, 4000);
    browser.close()
    var id = doc.select("#plList > li.plSel > div > div.plLength > div > input[type=checkbox]").attr("data-id");
    let response = fetch("https://truyenaudiocvv.com/api/getText", {
        method: "GET",
        queries: {
            dataType: "json",
            taskId: id
        }
    });
    if (response.ok) {
        let json = response.json();
        var content = json.content
    }
    return Response.success(content.replace("Nguồn Truyện Audio CV chấm com","").replace("<br />.<br />","").replace("<br> Cách Chương.<br>",""));

}