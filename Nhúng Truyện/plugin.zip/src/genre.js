function execute() {
    return Response.success([
        {
            "input": "1",
            "title": "Tiên Hiệp",
            "script": "gen1.js"
        },
        {
            "input": "2",
            "title": "Huyền Huyễn",
            "script": "gen1.js"
        },
        {
            "input": "3",
            "title": "Kỳ Ảo",
            "script": "gen1.js"
        },
        {
            "input": "4",
            "title": "Đô Thị",
            "script": "gen1.js"
        },
        {
            "input": "5",
            "title": "Khoa Huyễn",
            "script": "gen1.js"
        },
        {
            "input": "6",
            "title": "Võng Du",
            "script": "gen1.js"
        },
        {
            "input": "7",
            "title": "Dã Sử",
            "script": "gen1.js"
        },
        {
            "input": "8",
            "title": "Đồng Nhân",
            "script": "gen1.js"
        },
        {
            "input": "9",
            "title": "Cạnh Kỹ",
            "script": "gen1.js"
        },
        {
            "input": "10",
            "title": "Huyền Nghi",
            "script": "gen1.js"
        },
        {
            "input": "11",
            "title": "Kiếm Hiệp",
            "script": "gen1.js"
        },
        {
            "input": "111",
            "title": "Huyền Huyễn Ngôn Tình",
            "script": "gen1.js"
        },
        {
            "input": "123",
            "title": "Cổ Đại Ngôn Tình",
            "script": "gen1.js"
        },
        {
            "input": "161",
            "title": "Hiện Đại Ngôn Tình",
            "script": "gen1.js"
        },
        {
            "input": "319",
            "title": "Huyền Nghi Thần Quái",
            "script": "gen1.js"
        },
        {
            "input": "320",
            "title": "Lãng Mạn Thanh Xuân",
            "script": "gen1.js"
        },
        {
            "input": "321",
            "title": "Tiên Hiệp Kỳ Duyên",
            "script": "gen1.js"
        },
        {
            "input": "322",
            "title": "Khoa Huyễn Không Gian",
            "script": "gen1.js"
        }
    ]);
}