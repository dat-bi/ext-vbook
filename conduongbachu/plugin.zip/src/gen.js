function execute(url) {
    var novelList = [];
    novelList.push({
        name: "Con Đường Bá Chủ",
        link: "https://conduongbachu.net/",
        description: "Akay Hau",
        cover: "https://conduongbachu.net/assets/images/banner-book.webp"
    });
    return Response.success(novelList);
}