function execute() {
    return Response.success([
        {title: "最新更新", input:  "https://43zw.cc/", script: "gen.js"},
        // {title: "武侠修真", input:  "https://www.31bz.org/xiuzhen/", script: "gen.js"},
        // {title: "历史军事", input:  "https://www.31bz.org/lishi/", script: "gen.js"},
        // {title: "游戏竞技", input:  "https://www.31bz.org/wangyou/", script: "gen.js"},
        // {title: "都市言情", input:  "https://www.31bz.org/dushi/", script: "gen.js"},
        // {title: "科幻灵异", input:  "https://www.31bz.org/kehuan/", script: "gen.js"},
        // {title: "女生频道", input:  "https://www.31bz.org/nvpin/", script: "gen.js"},
        // {title: "排行榜", input:  "https://www.31bz.org/paihangbang/", script: "gen.js"}

    ]);
}