function execute() {
    return Response.success([
        {title: "Binh chuong KIEM LAI", input: "1", script: "gen.js"}
    ]);
}